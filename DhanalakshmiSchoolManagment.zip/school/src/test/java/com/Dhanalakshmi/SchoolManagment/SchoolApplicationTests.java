package com.Dhanalakshmi.SchoolManagment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolApplicationTests {

	@Test
	void contextLoads() {
	}

}
