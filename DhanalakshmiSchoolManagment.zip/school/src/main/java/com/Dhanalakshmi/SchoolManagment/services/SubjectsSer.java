package com.Dhanalakshmi.SchoolManagment.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Dhanalakshmi.SchoolManagment.models.Subjects;
import com.Dhanalakshmi.SchoolManagment.repository.SubjectsRepo;

import java.util.List;

@Service
public class SubjectsSer {
    @Autowired
    private SubjectsRepo subjectsRepo;
    public Subjects addSubjects(Subjects subjects) {return subjectsRepo.save(subjects);
    }

    public List<Subjects> getAllSubjects(){
        return subjectsRepo.findAll();
    }


}
