package com.Dhanalakshmi.SchoolManagment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.Dhanalakshmi.SchoolManagment.models.Parents;
import com.Dhanalakshmi.SchoolManagment.models.Student;
import com.Dhanalakshmi.SchoolManagment.models.Subjects;
import com.Dhanalakshmi.SchoolManagment.models.Teachers;
import com.Dhanalakshmi.SchoolManagment.services.SubjectsSer;
import com.Dhanalakshmi.SchoolManagment.services.TeachersSer;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
public class TeachersCon {
    @Autowired
    private TeachersSer teachersSer;

    @Autowired
    private SubjectsSer subjectsSer;



    @PostMapping("addTeacher")
    public String addVTypes(@ModelAttribute Teachers teachers,@ModelAttribute Subjects subjects, Model model){
//

        teachers.setSubjects(subjects);
        teachersSer.addTeacher(teachers);

        model.addAttribute("Subjects", subjectsSer.getAllSubjects());
        model.addAttribute("newTeacher", new Teachers());
        model.addAttribute("newSubject", new Subjects());


        return "TeachersAdd";

    }

    @GetMapping("Teachers")
    public String Teacher(Model model){

        model.addAttribute("Subjects", subjectsSer.getAllSubjects());
        model.addAttribute("newTeacher", new Teachers());
        model.addAttribute("newSubject", new Subjects());

        return "TeachersAdd";

    }


    @GetMapping("Teachersshow")
    public String Teachersshow(Model model){
        List<Teachers> Teacher =teachersSer.getTeachers();
        model.addAttribute("Teacher",  Teacher);
        return "Teachersshow";
    }

    @GetMapping("/Teachersshow/edit/{ID}")
    public String edit(@PathVariable("ID") long ID, Model model) {
        Teachers teacher = teachersSer.getTeacherByID(ID);
        model.addAttribute("teacher", teacher); // Use "teacher" instead of "Teachers" as the attribute name
        return "TeacherEdit";
    }

    @PostMapping("/Teachersshow/edit/UpdateTeacher")
    public String updateTeacher(@ModelAttribute Teachers teachers, Model model, HttpSession session) {
        Teachers updatedTeacher = teachersSer.updateTeacher(teachers.getID(), teachers);

        if (updatedTeacher != null) {
            model.addAttribute("newParent", new Parents());
            model.addAttribute("newStudent", new Student());
            session.setAttribute("msg", "Teacher Updated Successfully...");
            return "StudentAdd"; // Adjust the return page accordingly
        } else {
            // Handle the case where the teacher with the given ID was not found
            session.setAttribute("msg", "Teacher not found for ID: " + teachers.getID());
            return "errorPage"; // Create an error page or redirect as needed
        }
    }

     
        
    
}


