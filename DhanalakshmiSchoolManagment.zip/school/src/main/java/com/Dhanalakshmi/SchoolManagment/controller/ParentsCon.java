package com.Dhanalakshmi.SchoolManagment.controller;

import org.springframework.stereotype.Controller;

@Controller
public class ParentsCon {
}
