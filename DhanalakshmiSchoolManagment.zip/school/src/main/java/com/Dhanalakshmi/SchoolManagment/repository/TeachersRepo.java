package com.Dhanalakshmi.SchoolManagment.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Dhanalakshmi.SchoolManagment.models.Teachers;

@Repository
public interface TeachersRepo extends JpaRepository<Teachers,Long> {
}
