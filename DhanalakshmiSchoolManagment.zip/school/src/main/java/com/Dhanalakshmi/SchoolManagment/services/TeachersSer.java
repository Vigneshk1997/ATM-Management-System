package com.Dhanalakshmi.SchoolManagment.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Dhanalakshmi.SchoolManagment.models.Teachers;
import com.Dhanalakshmi.SchoolManagment.repository.TeachersRepo;

import java.util.List;
import java.util.Optional;

@Service
public class TeachersSer {

    @Autowired
    private TeachersRepo teacherRepo;

    public Teachers addTeacher(Teachers teachers) {
        return teacherRepo.save(teachers);
    }

    public List<Teachers> getTeachers() {
        return teacherRepo.findAll();
    }

    public Teachers getTeacherByID(long ID) {
        Optional<Teachers> optionalTeacher = teacherRepo.findById(ID);

        return optionalTeacher.orElse(null);
    }

    public Teachers updateTeacher(long ID, Teachers updatedTeacher) {
        Optional<Teachers> optionalExistingTeacher = teacherRepo.findById(ID);

        if (optionalExistingTeacher.isPresent()) {
            Teachers existingTeacher = optionalExistingTeacher.get();
            
            // Update the existing teacher's information with the provided values
            existingTeacher.setName(updatedTeacher.getName());
            existingTeacher.setSubjects(updatedTeacher.getSubjects());
            // ... other properties

            // Save the updated teacher to the database
            return teacherRepo.save(existingTeacher);
        }

        // Return null if the teacher with the given ID is not found
        return null;
    }
}
