package com.Dhanalakshmi.SchoolManagment.services;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Dhanalakshmi.SchoolManagment.models.Parents;
import com.Dhanalakshmi.SchoolManagment.repository.ParentsRepo;

@Service
public class ParentsSer {

    @Autowired
    private ParentsRepo parentsRepo;


    public Parents addParents(Parents parents){
        return parentsRepo.save(parents);
    }

}
